from tkinter import *
import os.path
from tkinter import Canvas,Frame

tk=Tk()
tk.title("BCD to 7-Segment Display")
tk.geometry("1200x600")

paint=PhotoImage(file=os.path.join(os.getcwd(),"Untitled.png"))
Label(tk,image=paint,height=400,width=400).grid(row=1,column=4,stick=NE)

display=Canvas(tk, width=340, height=340, bg="black")
display.grid(row=1,column=4,stick=N,pady=32)


#----------------------------------------------------------------------------------------------------------------#

led_A=display.create_line(75,60,270,60,fill="#2F2D2D",width=20)
led_B=display.create_line(270,60,270,170,fill="#2F2D2D",width=30)
led_C=display.create_line(270,170,270,280,fill="#2F2D2D",width=30)
led_D=display.create_line(75,280,270,280,fill="#2F2D2D",width=20)
led_E=display.create_line(75,170,75,280,fill="#2F2D2D",width=30)
led_F=display.create_line(75,170,75,60,fill="#2F2D2D",width=30)
led_G=display.create_line(75,170,270,170,fill="#2F2D2D",width=20)

led_DP=display.create_oval(300,300,320,320,fill="#2F2D2D")


ckt_on=False
#----------------------------------------------------------------------------------------------------------------#

input_options = ["0","1"]
clicked1=StringVar()
clicked1.set("0")

clicked2=StringVar()
clicked2.set("0")

clicked3=StringVar()
clicked3.set("0")

clicked4=StringVar()
clicked4.set("0")
#----------------------------------------------------------------------------------------------------------------#
def reset():
    ckt_on = False
    clear()
    clicked1.set("0")
    clicked2.set("0")
    clicked3.set("0")
    clicked4.set("0")
    ckt_button.configure(image=off)
    

def show_0():
    display.itemconfigure(led_A,fill="red")
    display.itemconfigure(led_B,fill="red")
    display.itemconfigure(led_C,fill="red")
    display.itemconfigure(led_D,fill="red")
    display.itemconfigure(led_E,fill="red")
    display.itemconfigure(led_F,fill="red")

def show_1():
    display.itemconfigure(led_B,fill="red")
    display.itemconfigure(led_C,fill="red")

def show_2():
    display.itemconfigure(led_A,fill="red")
    display.itemconfigure(led_B,fill="red")
    display.itemconfigure(led_G,fill="red")
    display.itemconfigure(led_D,fill="red")
    display.itemconfigure(led_E,fill="red")

def show_3():
    display.itemconfigure(led_A,fill="red")
    display.itemconfigure(led_B,fill="red")
    display.itemconfigure(led_C,fill="red")
    display.itemconfigure(led_G,fill="red")
    display.itemconfigure(led_D,fill="red")

def show_4():
    display.itemconfigure(led_F,fill="red")
    display.itemconfigure(led_B,fill="red")
    display.itemconfigure(led_G,fill="red")
    display.itemconfigure(led_C,fill="red")

def show_5():
    display.itemconfigure(led_A,fill="red")
    display.itemconfigure(led_F,fill="red")
    display.itemconfigure(led_G,fill="red")
    display.itemconfigure(led_C,fill="red")
    display.itemconfigure(led_D,fill="red")

def show_6():
    display.itemconfigure(led_A,fill="red")
    display.itemconfigure(led_F,fill="red")
    display.itemconfigure(led_G,fill="red")
    display.itemconfigure(led_C,fill="red")
    display.itemconfigure(led_D,fill="red")
    display.itemconfigure(led_E,fill="red")
  
def show_7():
    display.itemconfigure(led_A,fill="red")
    display.itemconfigure(led_B,fill="red")
    display.itemconfigure(led_C,fill="red")

def show_8():
    display.itemconfigure(led_A,fill="red")
    display.itemconfigure(led_B,fill="red")
    display.itemconfigure(led_C,fill="red")
    display.itemconfigure(led_D,fill="red")
    display.itemconfigure(led_E,fill="red")
    display.itemconfigure(led_F,fill="red")
    display.itemconfigure(led_G,fill="red")
def show_9():
    display.itemconfigure(led_A,fill="red")
    display.itemconfigure(led_B,fill="red")
    display.itemconfigure(led_C,fill="red")
    display.itemconfigure(led_D,fill="red")
    display.itemconfigure(led_G,fill="red")
    display.itemconfigure(led_F,fill="red")
def clear():
    display.itemconfigure(led_A,fill="#2F2D2D")
    display.itemconfigure(led_B,fill="#2F2D2D")
    display.itemconfigure(led_C,fill="#2F2D2D")
    display.itemconfigure(led_D,fill="#2F2D2D")
    display.itemconfigure(led_E,fill="#2F2D2D")
    display.itemconfigure(led_F,fill="#2F2D2D")
    display.itemconfigure(led_G,fill="#2F2D2D")


def switch():
    global ckt_on
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        clear()


def simulate():
    if ckt_on==True :
        if   clicked1.get()=="0" and clicked2.get()=="0" and clicked3.get()=="0" and clicked4.get()=="0":
            clear()
            show_0()
        elif clicked1.get()=="0" and clicked2.get()=="0" and clicked3.get()=="0" and clicked4.get()=="1":
            clear()
            show_1()
        elif clicked1.get()=="0" and clicked2.get()=="0" and clicked3.get()=="1" and clicked4.get()=="0":
            clear()
            show_2()
        elif clicked1.get()=="0" and clicked2.get()=="0" and clicked3.get()=="1" and clicked4.get()=="1":
            clear()
            show_3()
        elif clicked1.get()=="0" and clicked2.get()=="1" and clicked3.get()=="0" and clicked4.get()=="0":
            clear()
            show_4()
        elif clicked1.get()=="0" and clicked2.get()=="1" and clicked3.get()=="0" and clicked4.get()=="1":
            clear()
            show_5()
        elif clicked1.get()=="0" and clicked2.get()=="1" and clicked3.get()=="1" and clicked4.get()=="0":
            clear()
            show_6()
        elif clicked1.get()=="0" and clicked2.get()=="1" and clicked3.get()=="1" and clicked4.get()=="1":
            clear()
            show_7()
        elif clicked1.get()=="1" and clicked2.get()=="0" and clicked3.get()=="0" and clicked4.get()=="0":
            clear()
            show_8()
        elif clicked1.get()=="1" and clicked2.get()=="0" and clicked3.get()=="0" and clicked4.get()=="1":
            clear()
            show_9()
        else: clear()

    else:
        clear()

#----------------------------------------------------------------------------------------------------------------#

Label(tk,text="Input A3 (MSB)").grid(row=1,column=0,stick=NE)
drop3=OptionMenu(tk,clicked1,*input_options).grid(row=1,column=1,stick=N)

Label(tk,text="Input A2").grid(row=1,column=0,stick=NE,pady=122)
drop2=OptionMenu(tk,clicked2,*input_options).grid(row=1,column=1,stick=N,pady=120)

Label(tk,text="Input A1").grid(row=1,column=0,stick=NE,pady=243)
drop1=OptionMenu(tk,clicked3,*input_options).grid(row=1,column=1,stick=N,pady=240)

Label(tk,text="Input A0 (LSB)").grid(row=1,column=0,stick=NE,pady=364)
drop0=OptionMenu(tk,clicked4,*input_options).grid(row=1,column=1,stick=N,pady=360)

Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)

#----------------------------------------------------------------------------------------------------------------#

ic=PhotoImage(file=os.path.join(os.getcwd(),"7447.png"))
Label(tk,image=ic,height=400,width=400).grid(row=1,column=2,stick=N)

#----------------------------------------------------------------------------------------------------------------#

on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))
#----------------------------------------------------------------------------------------------------------------#

ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)

Button(tk,text="Simulate",command=simulate).grid(row=1,column=3,stick=N,pady=420) 
Button(tk,text="Reset All",command=reset).grid(row=1,column=4,stick=NE,pady=420) 

#----------------------------------------------------------------------------------------------------------------#
tk.mainloop()