from tkinter import *
import os.path

tk=Tk()
tk.title("Full Subtractor")
tk.geometry("1100x600")
ckt_on=False

ckt=PhotoImage(file=os.path.join(os.getcwd(),"fullsubtractorcircuit.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

Label(tk,image=ckt).grid(row=1,column=3,stick=NW)

input_options = ["0","1"]
A=IntVar()
A.set("0")

B=IntVar()
B.set("0")

C=IntVar()
C.set("0")

def switch():
    global ckt_on
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        op1.configure(image=red)
        op2.configure(image=red)
def difference():
        a=bool(A.get())
        b=bool(B.get())
        c=bool(C.get())
        if a^b^c==True:
            op1.configure(image=green)

        else:
            op1.configure(image=red)

def borrow():
        a=bool(A.get())
        b=bool(B.get())
        c=bool(C.get())
        if ((not a) and b) or ((not a) and c) or (b and c) ==True:
            op2.configure(image=green)
        
        else:
            op2.configure(image=red)

def reset():
    global ckt_on
    ckt_on = False
    ckt_button.configure(image=off)
    A.set("0")
    B.set("0")
    C.set("0")
    op1.configure(image=red)
    op2.configure(image=red)


def simulate():
    a=bool(A.get())
    b=bool(B.get())
    c=bool(C.get())
    if ckt_on==True:
        difference()
        borrow()
    else:
        op1.configure(image=red)
        op2.configure(image=red)       

drop1=OptionMenu(tk,A,*input_options).grid(row=1,column=1,stick=N,pady=30)
drop2=OptionMenu(tk,B,*input_options).grid(row=1,column=1,stick=N,pady=80)
drop3=OptionMenu(tk,C,*input_options).grid(row=1,column=1,stick=N,pady=130)

Label(tk,text="Input A").grid(row=1,column=0,stick=NE,pady=30)
Label(tk,text="Input B").grid(row=1,column=0,stick=NE,pady=80)
Label(tk,text="Input B in").grid(row=1,column=0,stick=NE,pady=130)

Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)

ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)

Button(tk,text="Simulate",command=simulate,width=15).grid(row=1,column=4,pady=340,sticky=N) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=1,column=5,padx=20,pady=100) 

op1=Label(tk,image=red)
op1.grid(row=1,column=4,stick=N,pady=45)
Label(tk,text="Difference").grid(row=1,column=5,stick=NW,pady=55)

op2=Label(tk,image=red)
op2.grid(row=1,column=4,stick=N,pady=230)
Label(tk,text="Borrow").grid(row=1,column=5,stick=NW,pady=235)

tk.mainloop()