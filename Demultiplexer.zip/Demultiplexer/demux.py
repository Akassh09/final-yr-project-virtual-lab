from tkinter import *
import os.path

tk=Tk()
tk.title("4:1 Multiplexer using logic gates")
tk.geometry("1080x700")
ckt_on=False


ckt=PhotoImage(file=os.path.join(os.getcwd(),"demux.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

Label(tk,image=ckt).grid(row=1,column=3,stick=NW)

input_options = ["0","1"]
S0=IntVar()
S0.set("0")

S1=IntVar()
S1.set("0")

I=IntVar()
I.set("0")


def switch():
    global ckt_on
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        op1.configure(image=red)
        op2.configure(image=red)
        op3.configure(image=red)

def reset():
    global ckt_on
    ckt_on = False
    ckt_button.configure(image=off)
    I.set("0")
    S0.set("0")
    S1.set("0")
    op1.configure(image=red)
    op2.configure(image=red)
    op3.configure(image=red)
    op4.configure(image=red)

def simulate():
    s0=bool(S0.get())
    s1=bool(S1.get())
    i=bool(I.get())
    if ckt_on==True:
        if i and (not s1) and (not s0)==True:
            op1.configure(image=red)
            op2.configure(image=red)
            op3.configure(image=red)
            op4.configure(image=green)
        elif i and (not s1) and s0 ==True:
            op1.configure(image=red)
            op2.configure(image=red)
            op3.configure(image=green)
            op4.configure(image=red)
        elif i and s1 and (not s0)==True:
            op1.configure(image=red)
            op2.configure(image=green)
            op3.configure(image=red)
            op4.configure(image=red)
        elif i and s0 and s1==True:
            op1.configure(image=green)
            op2.configure(image=red)
            op3.configure(image=red)
            op4.configure(image=red) 

        else:
            op1.configure(image=red)
            op2.configure(image=red)
            op3.configure(image=red)
            op4.configure(image=red)          
    else:
        op1.configure(image=red)
        op2.configure(image=red)
        op3.configure(image=red)
        op4.configure(image=red)

drop2=OptionMenu(tk,S1,*input_options).grid(row=1,column=1,stick=N,pady=140)
drop3=OptionMenu(tk,S0,*input_options).grid(row=1,column=1,stick=N,pady=200)
drop4=OptionMenu(tk,I,*input_options).grid(row=1,column=1,stick=N,pady=50)

Label(tk,text="Selection Line S1").grid(row=1,column=0,stick=NE,pady=135)
Label(tk,text="Selection Line S0").grid(row=1,column=0,stick=NE,pady=195)
Label(tk,text="Input I").grid(row=1,column=0,stick=NE,pady=45)

Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)

ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)

Button(tk,text="Simulate",command=simulate,width=15).grid(row=1,column=4,pady=460,sticky=N) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=1,column=5,padx=20,pady=100) 

op1=Label(tk,image=red)
op1.grid(row=1,column=4,stick=N,pady=45)
Label(tk,text="Output Y3").grid(row=1,column=5,stick=NW,pady=45)

op2=Label(tk,image=red)
op2.grid(row=1,column=4,stick=N,pady=145)
Label(tk,text="Output Y2").grid(row=1,column=5,stick=NW,pady=145)

op3=Label(tk,image=red)
op3.grid(row=1,column=4,stick=N,pady=245)
Label(tk,text="Output Y1").grid(row=1,column=5,stick=NW,pady=245)

op4=Label(tk,image=red)
op4.grid(row=1,column=4,stick=N,pady=340)
Label(tk,text="Output Y0").grid(row=1,column=5,stick=NW,pady=340)

tk.mainloop()