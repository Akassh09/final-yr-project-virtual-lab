from tkinter import *
import os.path

tk=Tk()
tk.title("Parallel Input Serial Output")
tk.geometry("1200x700")
ckt_on=False
n=0

input_options = ["0","1"]

i=IntVar()
i.set("0")

j=IntVar()
j.set("0")

k=IntVar()
k.set("0")

l=IntVar()
l.set("0")

ckt=PhotoImage(file=os.path.join(os.getcwd(),"Digital Electronics Lab\PISO\piso.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"Digital Electronics Lab\PISO\\red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"Digital Electronics Lab\PISO\green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"Digital Electronics Lab\PISO\on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"Digital Electronics Lab\PISO\off.png"))

Label(tk,image=ckt).grid(row=2,column=2,stick=NW)

def switch():
    global ckt_on,prev
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)

def reset():
    global n
    n=0
    ckt_on==False
    ckt_button.configure(image=off)
    i.set("0")
    j.set("0")
    k.set("0")
    l.set("0")
    op1.configure(image=red)

    x.configure(text="Cock Cycle: ---",foreground="Red")
    

def clock():
    global n
    if ckt_on==True:
        n=n+1
        x.configure(text="Clock Cycle: "+str(n),foreground="Green")
    else:
        pass

    pass

drop1=OptionMenu(tk,i,*input_options).grid(row=1,column=2,stick=NW,padx=85)
drop2=OptionMenu(tk,j,*input_options).grid(row=1,column=2,stick=NW,padx=240)
drop3=OptionMenu(tk,k,*input_options).grid(row=1,column=2,stick=NW,padx=455)
drop4=OptionMenu(tk,l,*input_options).grid(row=1,column=2,stick=NW,padx=670)
Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','10','bold')).grid(row=0,column=0,padx=10,stick=NE)

ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=0,sticky=N,padx=10,pady=25)

op1=Label(tk,image=red)
op1.grid(row=1,column=2,stick=NW,padx=870)

Button(tk,text="Clock",command=clock,width=15).grid(row=3,column=2,sticky=W,pady=10) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=3,column=2,sticky=W,pady=10,padx=887) 

x=Label(tk,text="Cock Cycle: ---",font=('Courier','12','bold'),foreground="Red")
x.grid(row=4,column=2,stick=NW,pady=20)

tk.mainloop()