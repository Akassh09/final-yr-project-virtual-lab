from tkinter import *
from tkinter import Canvas,Frame
import os.path


tk=Tk()
ckt_on=False
art_trigger=False
bulb=False
tk.title("Flame sensor interfacee")
tk.geometry("1190x560")
fig=PhotoImage(file=os.path.join(os.getcwd(),"Capture.png"))
Label(tk,image=fig,height=200,width=440).grid(row=1,column=1) 

#------------------------------------------------------------------------------#
def arena_set():

    if clicked.get()=="Analog Mode":
            arena.delete("all")                                #for clearing the arena canvas first
            arena.create_line(200,0,200,205,dash=(2,2),fill="#67B7D1")
            arena.create_line(400,0,400,205,dash=(2,4),fill="#296E85")
            label1.config(text="0cm       100       200       300       400       500cm       600       700       800       900       1000cm       1100                            ∞  ",foreground="red")

    elif clicked.get()=="Digital  Mode":
            arena.delete("all")
            arena.create_line(300,0,300,200,dash=(2,4),fill="red")
            label1.config(text="Detectable Range                                                                               Undetectable Range",foreground="blue")

def switch1():
    global ckt_on
    
    if ckt_on==False and art_trigger==False:           #if the earlier state of ckt button is off and is clicked to make it on
        ckt_on = True
        ckt_button.configure(image=on)
        bulb.config(image=bulb_off)
        lcd.configure(bg="#58C571")
        lcd.itemconfigure(lcd_text,text=("NO  FLAME  DETECTED"))
        arena_set()
    elif ckt_on==False and art_trigger==True:            
        ckt_on = True
        ckt_button.configure(image=on)
        bulb.config(image=bulb_on)
        lcd.configure(bg="#58C571")
        lcd.itemconfigure(lcd_text,text=("!! FLAME DETECTED !!\n\n\n\n\n\nDigitalPin Reading = \n 1"))
        arena_set()

    else:
        ckt_on = False
        ckt_button.configure(image=off)
        bulb.config(image=bulb_off)
        lcd.configure(bg="#207E35")
        lcd.itemconfigure(lcd_text,text=(""))
        arena_set()
#------------------------------------------------------------------------------#
def switch2():  #switch for artificial trigger
    global art_trigger
    if art_trigger==True and ckt_on==True:                    #that is if artificial trigger is earlier on and then the button is clicked to make it off
        trig_button.configure(image=off)
        art_trigger = False
        bulb.config(image=bulb_off)
        lcd.configure(bg="#58C571")
        lcd.itemconfigure(lcd_text,text=("NO FLAME  DETECTED \n\n\n\n\n\nDigitalPin Reading =\n 0"))
    elif art_trigger==True and ckt_on==False:
        trig_button.configure(image=off)
        art_trigger = False
        bulb.configure(image=bulb_off)
        lcd.configure(bg="#207E35")
        lcd.itemconfigure(lcd_text,text=(""))
    elif art_trigger==False and ckt_on==True:                 #that is if the artificial trigger is already off and then it is clicked to make it on
        trig_button.configure(image = on)
        art_trigger = True
        bulb.configure(image=bulb_on)
        lcd.configure(bg="#58C571")
        lcd.itemconfigure(lcd_text,text=("!! FLAME DETECTED !!\n\n\n\n\n\nDigitalPin Reading =\n 1"))
    elif art_trigger==False and ckt_on==False:
        trig_button.configure(image = on)
        bulb.configure(image=bulb_off)
        art_trigger = True
        lcd.configure(bg="#207E35")
        lcd.itemconfigure(lcd_text,text=(""))
#------------------------------------------------------------------------------#
def move(event):
    global fire
    global flame
    arena_set()
    fire=PhotoImage(file=os.path.join(os.getcwd(),"fire.png"))
    flame=arena.create_image(event.x,event.y,image=fire)

    if ckt_on==True and art_trigger==False:
        lcd.configure(bg="#58C571")
        if clicked.get()=="Analog Mode":
            if 0<=event.x<200:
                bulb.configure(image=bulb_on)
                lcd.itemconfigure(lcd_text,text=("!! FLAME DETECTED !!\n Close   Fire\n\nEst. Distance=\n 0cm to 450cm\n\nAnalogPin reading =\n "+str(abs(int(round(1023-(event.x/400*1023),0))))))
                #This is an arbitrary equation to generate the analog pin value w.r.t. the mouse distace (may not be perfect)
                #Mouse location divided by 400(max possible location for active ir sensing) multiplied by 1023(max analog bit in arduino for 5v)
                #round to rermove decimal part ,int to convert to interger abs to get positive value,str to convert to string
                
            elif 200<=event.x<400:
                bulb.configure(image=bulb_on)
                lcd.itemconfigure(lcd_text,text=("!! FLAME DETECTED !!\n Distant Fire\n\nEst. Distance=\n 450cm to 950cm\n\nAnalogPin reading =\n "+str(abs(int(round(1023-(event.x/400*1023),0))))))

            else:
                bulb.configure(image=bulb_off)
                lcd.itemconfigure(lcd_text,text=("NO  FLAME  DETECTED \n\n\n\n\n\nAnalogPin Reading =\n 0"))
            
        elif clicked.get()=="Digital  Mode":
            if 0<=event.x<300:
                bulb.configure(image=bulb_on)
                lcd.itemconfigure(lcd_text,text=("!! FLAME DETECTED !!\n\n\n\n\n\nDigitalPin Reading =\n 1"))
            else:
                bulb.configure(image=bulb_off)
                lcd.itemconfigure(lcd_text,text=("NO  FLAME  DETECTED \n\n\n\n\n\nDigitalPin Reading =\n 0"))

    elif ckt_on==True and art_trigger==True:
        bulb.configure(image=bulb_on)
        lcd.configure(bg="#58C571")
        lcd.itemconfigure(lcd_text,text=("!! FLAME DETECTED !!\n\n\n\n\n\nDigitalPin Reading =\n 1"))
    else:
        lcd.configure(bg="#207E35")
        bulb.configure(image=bulb_off)
        lcd.itemconfigure(lcd_text,text=(""))

#------------------------------------------------------------------------------#
def reset():
   ckt_button.configure(image=off)
   trig_button.configure(image=off)
   bulb.config(image=bulb_off)
   lcd.itemconfigure(lcd_text,text="")
   clicked.set("Analog Mode")
   arena.delete("all")
   lcd.configure(bg='#207E35')
   label1.config(text="")

#------------------------------------------------------------------------------#

on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))
#------------------------------------------------------------------------------#
trig_button = Button(tk, image = off, bd = 0,command = switch2)
trig_button.grid(row=2,column=0)
#------------------------------------------------------------------------------#
options=["Analog Mode","Digital  Mode"]
clicked=StringVar()
clicked.set("Analog Mode")
drop=OptionMenu(tk,clicked,*options)
drop.grid(row=1,column=0,sticky=N)
drop.configure(width=15)
#------------------------------------------------------------------------------#
lcd=Canvas(tk,height=200,width=300,bg="#207E35")
lcd.grid(row=3,column=1)
lcd_text=lcd.create_text(140,100,text="",fill="white",font=('Courier','12','bold'))
#------------------------------------------------------------------------------#

arena=Canvas(tk, width=600, height=205, bg="white",)
arena.grid(row=1,column=2)
arena.bind("<B1-Motion>", move)

#------------------------------------------------------------------------------#
label1=Label(tk,text="",foreground="red")
label1.grid(row=0,column=2,pady=5,sticky=N)
#------------------------------------------------------------------------------#
label2=Label(tk,text="Use Left Click to move the flame in the above arena")
label2.grid(row=2,column=2)
#------------------------------------------------------------------------------#
label3=Label(tk,text="Microcontroller Screen")
label3.grid(row=4,column=1)
#------------------------------------------------------------------------------#
label4=Label(tk,text="Output")
label4.grid(row=2,column=1,sticky=E,padx=15)
#------------------------------------------------------------------------------#
label5=Label(tk,text="Circuit Switch")
label5.grid(row=1,column=0,pady=65,sticky=S)
#------------------------------------------------------------------------------#
label6=Label(tk,text="Manual Trigger\n(uses DigitalPin)")
label6.grid(row=3,column=0,sticky=N,padx=10)
#------------------------------------------------------------------------------#
btn3=Button(tk,text="Reset All",command=reset).grid(row=5,column=0)
#------------------------------------------------------------------------------#
bulb_on=PhotoImage(file=os.path.join(os.getcwd(),"bulb on.png"))
bulb_off=PhotoImage(file=os.path.join(os.getcwd(),"bulb off.png"))
bulb=Label(tk,image=bulb_off,width=70,height=70)
bulb.grid(row=1,column=1,sticky=SE)
#------------------------------------------------------------------------------#
ckt_button = Button(tk, image = off, bd = 0,command = switch1)
ckt_button.grid(row=1,column=0)
#------------------------------------------------------------------------------#


tk.mainloop()
