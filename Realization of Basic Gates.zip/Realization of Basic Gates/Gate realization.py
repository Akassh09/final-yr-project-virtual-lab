from tkinter import *
import os.path
from tkinter import Canvas,Frame

tk=Tk()
tk.title("Reealization of Gates")
tk.geometry("700x1080")

is_on1=False
is_on2=False
is_on3=False
is_on4=False
is_on5=False
is_on6=False
is_on7=False
is_on8=False
is_on9=False
is_on10=False
is_on11=False

on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))
op_on=PhotoImage(file=os.path.join(os.getcwd(),"bulb on.png"))
op_off=PhotoImage(file=os.path.join(os.getcwd(),"bulb off.png"))

#------------------------------------------------------------------------------#
IC_NAND=PhotoImage(file=os.path.join(os.getcwd(),"7400.png"))
IC_NOR=PhotoImage(file=os.path.join(os.getcwd(),"7402.png"))
IC_NOT=PhotoImage(file=os.path.join(os.getcwd(),"7404.png"))
IC_AND=PhotoImage(file=os.path.join(os.getcwd(),"7408.png"))
IC_OR=PhotoImage(file=os.path.join(os.getcwd(),"7432.png"))
IC_XOR=PhotoImage(file=os.path.join(os.getcwd(),"74136.png"))

#------------------------------------------------------------------------------#

Label(tk,image=IC_AND).grid(row=1,column=2)
Label(tk,image=IC_OR).grid(row=3,column=2)
Label(tk,image=IC_NAND).grid(row=5,column=2)
Label(tk,image=IC_NOR).grid(row=7,column=2)
Label(tk,image=IC_XOR).grid(row=9,column=2)
Label(tk,image=IC_NOT).grid(row=11,column=2)

#------------------------------------------------------------------------------#

and_op=Label(tk,image=op_off)
and_op.grid(row=1,column=3,stick=W,padx=50)
or_op=Label(tk,image=op_off)
or_op.grid(row=3,column=3,stick=W,padx=50)
nand_op=Label(tk,image=op_off)
nand_op.grid(row=5,column=3,stick=W,padx=50)
nor_op=Label(tk,image=op_off)
nor_op.grid(row=7,column=3,stick=W,padx=50)
xor_op=Label(tk,image=op_off)
xor_op.grid(row=9,column=3,stick=W,padx=50)
not_op=Label(tk,image=op_off)
not_op.grid(row=11,column=3,stick=W,padx=50)

#------------------------------------------------------------------------------#

def AND():
    if (is_on1 and is_on2)==True:
        and_op.config(image =op_on)
    else:
        and_op.config(image =op_off)

def OR():
    if (is_on3 or is_on4)==True:
        or_op.config(image =op_on)
    else:
        or_op.config(image =op_off)

def NAND():
    if not(is_on5 and is_on6)==True:
        nand_op.config(image =op_on)
    else:
        nand_op.config(image =op_off)

def NOR():
    if not(is_on7 or is_on8)==True:
        nor_op.config(image =op_on)
    else:
        nor_op.config(image =op_off)

def XOR():
    if (is_on9 and not is_on10) or (not is_on9 and is_on10):
        xor_op.config(image=op_on)
    else:
        xor_op.config(image=op_off)

def NOT():
    if not(is_on11)==True:
        not_op.config(image=op_on)
    else:
        not_op.config(image=op_off)

#------------------------------------------------------------------------------#
def reset():

    and_in_1.config(image = off)
    and_in_2.config(image =off)
    and_op.config(image =op_off)

    or_in_1.config(image = off)
    or_in_2.config(image =off)
    or_op.config(image =op_off)

    nand_in_1.config(image =off)
    nand_in_2.config(image =off)
    nand_op.config(image =op_off)

    nor_in_1.config(image =off)
    nor_in_2.config(image =off)
    nor_op.config(image =op_off)

    xor_in_1.config(image =off)
    xor_in_2.config(image =off)
    xor_op.config(image =op_off)

    not_in_1.config(image =off)
    not_op.config(image =op_off)

#------------------------------------------------------------------------------#

def switch1():
    global is_on1
    if is_on1:
        and_in_1.config(image = off)
        is_on1 = False
        and_op.config(image =op_on)


    else:
        and_in_1.config(image = on)
        is_on1 = True
        and_op.config(image =op_off)
    AND()

#------------------------------------------------------------------------------#
def switch2():
    global is_on2
    if is_on2:
        and_in_2.config(image = off)
        is_on2 = False
        
    else:
        and_in_2.config(image = on)
        is_on2 = True
    AND()
#------------------------------------------------------------------------------#
def switch3():
    global is_on3
    if is_on3:
        or_in_1.config(image = off)
        is_on3 = False
    else:
        or_in_1.config(image = on)
        is_on3 = True
    OR()
#------------------------------------------------------------------------------#
def switch4():
    global is_on4
    if is_on4:
        or_in_2.config(image = off)
        is_on4 = False
    else:
        or_in_2.config(image = on)
        is_on4 = True
    OR()
#------------------------------------------------------------------------------#
def switch5():
    global is_on5
    if is_on5:
        nand_in_1.config(image = off)
        is_on5 = False
    else:
        nand_in_1.config(image = on)
        is_on5 = True
    NAND()
#------------------------------------------------------------------------------#
def switch6():
    global is_on6
    if is_on6:
        nand_in_2.config(image = off)
        is_on6 = False
    else:
        nand_in_2.config(image = on)
        is_on6 = True
    NAND()
#------------------------------------------------------------------------------#
def switch7():
    global is_on7
    if is_on7:
        nor_in_1.config(image = off)
        is_on7 = False
    else:
        nor_in_1.config(image = on)
        is_on7 = True
    NOR()
#------------------------------------------------------------------------------#
def switch8():
    global is_on8
    if is_on8:
        nor_in_2.config(image = off)
        is_on8 = False
    else:
        nor_in_2.config(image = on)
        is_on8 = True
    NOR()
#------------------------------------------------------------------------------#
def switch9():
    global is_on9
    if is_on9:
        xor_in_1.config(image = off)
        is_on9 = False
    else:
        xor_in_1.config(image = on)
        is_on9 = True
    XOR()
#------------------------------------------------------------------------------#
def switch10():
    global is_on10
    if is_on10:
        xor_in_2.config(image = off)
        is_on10 = False
    else:
        xor_in_2.config(image = on)
        is_on10 = True
    XOR()
#------------------------------------------------------------------------------#
def switch11():
    global is_on11
    if is_on11:
        not_in_1.config(image = off)
        is_on11 = False
    else:
        not_in_1.config(image = on)
        is_on11 = True
    NOT()
#------------------------------------------------------------------------------#

label1=Label(tk,text="AND Gate",foreground="green")
label1.grid(row=0,column=0,stick=W)

and_in_1= Button(tk, image = off, bd = 0,command = switch1)
and_in_1.grid(row=1,column=1,sticky=N,pady=45)

and_in_2= Button(tk, image = off, bd = 0,command = switch2)
and_in_2.grid(row=1,column=1,sticky=S,pady=40)

#------------------------------------------------------------------------------#
label2=Label(tk,text="OR Gate",foreground="green")
label2.grid(row=2,column=0,stick=W)

or_in_1 = Button(tk, image = off, bd = 0,command = switch3)
or_in_1.grid(row=3,column=1,sticky=N,pady=45)

or_in_2= Button(tk, image = off, bd = 0,command = switch4)
or_in_2.grid(row=3,column=1,sticky=S,pady=40)
#------------------------------------------------------------------------------#
label3=Label(tk,text="NAND Gate",foreground="green")
label3.grid(row=4,column=0,stick=W)

nand_in_1 = Button(tk, image = off, bd = 0,command = switch5)
nand_in_1.grid(row=5,column=1,sticky=N,pady=45)

nand_in_2 = Button(tk, image = off, bd = 0,command = switch6)
nand_in_2.grid(row=5,column=1,sticky=S,pady=40)
#------------------------------------------------------------------------------#
label4=Label(tk,text="NOR Gate",foreground="green")
label4.grid(row=6,column=0,stick=W)

nor_in_1 = Button(tk, image = off, bd = 0,command = switch7)
nor_in_1.grid(row=7,column=1,sticky=N,pady=45)

nor_in_2 = Button(tk, image = off, bd = 0,command = switch8)
nor_in_2.grid(row=7,column=1,sticky=S,pady=40)
#------------------------------------------------------------------------------#
label5=Label(tk,text="XOR Gate",foreground="green")
label5.grid(row=8,column=0,stick=W)

xor_in_1 = Button(tk, image = off, bd = 0,command = switch9)
xor_in_1.grid(row=9,column=1,sticky=N,pady=45)

xor_in_2 = Button(tk, image = off, bd = 0,command = switch10)
xor_in_2.grid(row=9,column=1,sticky=S,pady=40)
#------------------------------------------------------------------------------#
label6=Label(tk,text="NOT Gate",foreground="green")
label6.grid(row=10,column=0,stick=W)

not_in_1= Button(tk, image = off, bd = 0,command = switch11)
not_in_1.grid(row=11,column=1)

#------------------------------------------------------------------------------#

btn3=Button(tk,text="Reset All",command=reset).grid(row=11,column=4,stick=S,pady=30)

tk.mainloop()