from ssl import OP_NO_TLSv1_2
from tkinter import *
import os.path
from tkinter import Canvas,Frame


tk=Tk()
tk.title("Binary Code to Gray Code")
tk.geometry("1080x600")
ckt_on=False

ckt=PhotoImage(file=os.path.join(os.getcwd(),"ic.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

Label(tk,image=ckt).grid(row=1,column=3,stick=NW)

op0=Label(tk,image=red)
op0.grid(row=1,column=4,stick=N,pady=30)

op1=Label(tk,image=red)
op1.grid(row=1,column=4,stick=N,pady=135)

op2=Label(tk,image=red)
op2.grid(row=1,column=4,stick=N,pady=245)

op3=Label(tk,image=red)
op3.grid(row=1,column=4,stick=N,pady=325)

input_options = ["0","1"]
B0=StringVar()
B0.set("0")

B1=StringVar()
B1.set("0")

B2=StringVar()
B2.set("0")

B3=StringVar()
B3.set("0")


def reset():
    global ckt_on
    ckt_on = False
    B0.set("0")
    B1.set("0")
    B2.set("0")
    B3.set("0")
    ckt_button.configure(image=off)
    op0.configure(image=red)
    op1.configure(image=red)
    op2.configure(image=red)
    op3.configure(image=red)

def switch():
    global ckt_on
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        op0.configure(image=red)
        op1.configure(image=red)
        op2.configure(image=red)
        op3.configure(image=red)


def simulate():
    def G0():
        if int(B0.get())^int(B1.get())==True:op0.configure(image=green)
        else:op0.configure(image=red)
    def G1():
        if int(B2.get())^int(B1.get())==True:op1.configure(image=green)
        else:op1.configure(image=red)
    def G2():
        if int(B3.get())^int(B2.get())==True:op2.configure(image=green)
        else:op2.configure(image=red)
    def G3():
        if int(B3.get())==True:op3.configure(image=green)
        else:op3.configure(image=red)

    if ckt_on==True:
        G0()
        G1()
        G2()
        G3()
    else:
        op0.configure(image=red)
        op1.configure(image=red)
        op2.configure(image=red)
        op3.configure(image=red)



drop0=OptionMenu(tk,B0,*input_options).grid(row=1,column=1,stick=N,pady=30)
drop1=OptionMenu(tk,B1,*input_options).grid(row=1,column=1,stick=N,pady=150)
drop2=OptionMenu(tk,B2,*input_options).grid(row=1,column=1,stick=N,pady=245)
drop3=OptionMenu(tk,B3,*input_options).grid(row=1,column=1,stick=N,pady=340)

Label(tk,text="Input B0 (LSB)").grid(row=1,column=0,stick=NE,pady=30)
Label(tk,text="Output G0 (LSB)").grid(row=1,column=5,stick=NW,pady=30)


Label(tk,text="Input B1").grid(row=1,column=0,stick=NE,pady=152)
Label(tk,text="Output G1").grid(row=1,column=5,stick=NW,pady=144)


Label(tk,text="Input B2").grid(row=1,column=0,stick=NE,pady=248)
Label(tk,text="Output G2").grid(row=1,column=5,stick=NW,pady=248)

Label(tk,text="Input B3 (MSB)").grid(row=1,column=0,stick=NE,pady=344)
Label(tk,text="Output G3 (MSB)").grid(row=1,column=5,stick=NW,pady=336)


Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)



ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)

Button(tk,text="Simulate",command=simulate,width=15).grid(row=1,column=4,pady=420,sticky=N) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=1,column=5,padx=20,pady=60) 

tk.mainloop()