from tkinter import *
from tkinter import Canvas,Frame
import os.path

ckt_on=False

tk=Tk()
x=DoubleVar()  
y=DoubleVar()
tk.title("Soil Moisture Sensor Interface")
tk.geometry("940x680")

fig=PhotoImage(file=os.path.join(os.getcwd(),"circuit.png"))
Label(tk,image=fig).grid(row=1,column=1)

on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

def switch1():
    global ckt_on
    if ckt_on==False:
        ckt_button.configure(image=on)
        ckt_on = True
    else:
        ckt_button.configure(image=off)
        ckt_on = False

def simulate():
    analog=round(1023-(x.get()/100*1023),2)
    potent=round(1023-(y.get())/10000*1023,3)
    outputV=round(analog/1023*4.2,3)

    if  ckt_on==True and clicked.get()=="Analog Mode":
        lcd.configure(bg='#58C571')
        multimeter.configure(bg='#7576C2')
        multimeter.itemconfigure(multimeter_text,text=("Output Pin Voltage :\n "+str(outputV)+" V"))##############################################str(outputV)
        if analog<500:
            lcd.itemconfigure(lcd_text,text=("Analog Reading:\n"+str(analog) +"\n\n\nInference:\nSoil is too wet"))
        elif 500<=analog<=700:
            lcd.itemconfigure(lcd_text,text=("Analog Reading:\n"+str(analog) +"\n\n\nInference:\nSoil moisture is\nin right range"))
        else:
            lcd.itemconfigure(lcd_text,text=("Analog Reading:\n"+str(analog) +"\n\n\nInference:\nSoil is too dry"))

    elif  ckt_on==True and clicked.get()=="Digital Mode":
        lcd.configure(bg='#58C571')
        multimeter.configure(bg='#7576C2')
        if analog>=potent:
            lcd.itemconfigure(lcd_text,text=("Digital Reading: 1\n\n\nInference:\nSoil is Dry"))
            multimeter.itemconfigure(multimeter_text,text=("Output Pin Voltage :\n "+str(outputV)+" V"))
        else:
            lcd.itemconfigure(lcd_text,text=("Digital Reading: 0\n\n\nInference:\nSoil is Wet"))
            multimeter.itemconfigure(multimeter_text,text=("Output Pin Voltage :\n "+str(outputV)+" V"))
    else:
        lcd.configure(bg="#2EAD4B")
        lcd.itemconfigure(lcd_text,text=(""))
        multimeter.configure(bg='#7576C2')
        multimeter.itemconfigure(multimeter_text,text=("Output Pin Voltage :\n "+str(outputV)+" V"))


def reset():
    global ckt_on
    ckt_on=False
    ckt_button.configure(image=off)
    sld.set(0)
    pot.set(4500)
    clicked.set("Analog Mode")
    lcd.configure(bg='#2EAD4B')
    multimeter.configure(bg='#4244A4')
    lcd.itemconfigure(lcd_text,text="")
    multimeter.itemconfigure(multimeter_text,text="")


ckt_button = Button(tk, image = off, bd = 0,command = switch1)
ckt_button.grid(row=0,column=1,sticky=W)

smt_button = Button(tk,text="Simulate",width=15,command = simulate)
smt_button.grid(row=2,column=3,sticky=S,pady=90)

rst_button = Button(tk,text="Reset",width=15,command = reset)
rst_button.grid(row=2,column=3,sticky=S)


Label(tk,text="Circuit Switch").grid(row=0,column=0,sticky=NW,padx=10,pady=10)
Label(tk,text="Multimeter Screen").grid(row=3,column=1,sticky=W,padx=70)
Label(tk,text="Microcontroller Screen").grid(row=3,column=1,sticky=E,padx=70)
Label(tk,text="Moisture Content\n(w/w %)").grid(row=2,column=2,sticky=N,padx=20)
Label(tk,text="Potentiometer(Ω)\n (To set the threshold\n in Digital mode)",foreground='red').grid(row=2,column=3,sticky=N)
Label(tk,text="Working Mode").grid(row=0,column=2,sticky=E)


multimeter=Canvas(tk,height=200,width=250,bg="#4244A4")
multimeter.grid(row=2,column=1,sticky=NW)
multimeter_text=multimeter.create_text(120,100,text="",fill="white",font=('Courier','12','bold'))

lcd=Canvas(tk,height=200,width=250,bg="#2EAD4B")
lcd.grid(row=2,column=1,sticky=NE)
lcd_text=lcd.create_text(120,100,text="",fill="white",font=('Courier','12','bold'))

sld=Scale(tk,from_=100,to=0,resolution=1,variable=x,length=300,orient=VERTICAL,tickinterval=10)
sld.grid(row=1,column=2)

pot=Scale(tk,from_=10000,to=0,resolution=100,variable=y,length=300,orient=VERTICAL,tickinterval=1000)
pot.grid(row=1,column=3,sticky=W,padx=25)
pot.set(4500)

options=["Analog Mode","Digital Mode"]
clicked=StringVar()
clicked.set("Analog Mode")
drop=OptionMenu(tk,clicked,*options)
drop.grid(row=0,column=3,sticky=N,pady=10)
drop.configure(width=15)
tk.mainloop()