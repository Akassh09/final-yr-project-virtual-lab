from tkinter import *
from tkinter import filedialog as fd
from tkinter import Canvas,Frame


def use_multimeter():
    t=x.get()
    label1.config(text=str(t)+' °C')
    analogread=(((t/100)+0.5)/5)*1024
    pin_volt=analogread*5.0/1024
    multimeter.itemconfigure(multimeter_text,text=('Analog Output Pin Voltage:\n'+str(pin_volt)+'V'))
    multimeter.configure(bg='#7576C2')
    
def use_microcontroller():
    t=x.get()
    label1.config(text=str(t)+' °C')
    analogread=((float(t)/100)+0.5)*1024/5
    c=(((analogread/1024)*5.0)-0.5)*100   #1)find percentage of input reading
                                          #2)multiply by 5V to get voltage
                                          #3)subtract the offset
                                          #convert to degree celcius
    f=(((c*9.0)/5.0)+32.0)
    if clicked.get()=="Temperature in Fahrenheit":
        lcd.itemconfigure(lcd_text,text=('AnalogPin reading:\n'+str(analogread)+'\n\nCalculated Temperature:\n'+str(f)+'°F'))
    else:
        lcd.itemconfigure(lcd_text,text=('AnalogPin reading:\n'+str(analogread)+'\n\nCalculated Temperature:\n'+str(c)+'°C'))
    lcd.configure(bg='#58C571')
    

def reset():
    sld.set(0)
    lcd.configure(bg='#2EAD4B')
    multimeter.configure(bg='#4244A4')
    label1.config(text="-----")
    clicked.set("Show temperature in Celsius")
    lcd.itemconfigure(lcd_text,text="")
    multimeter.itemconfigure(multimeter_text,text="")


tk=Tk()

tk.title("Temperature measurement using TMP36 temperature sensor")
tk.geometry("1200x580")
x=DoubleVar()
a=fd.askopenfilename()                                           
fig=PhotoImage(file=a)                                            
Label(tk,image=fig).grid(row=3,column=1)

Label(tk,text="Set the temperature (°C)").grid(row=0,column=0)

sld=Scale(tk,from_=-40,to=125,resolution=0.1,variable=x,length=400,orient=HORIZONTAL)
sld.grid(row=0,column=1)

Label(tk,text="Surrounding Temperature  :        ").grid(row=2,column=0)
label1=Label(tk,text="-----",foreground="red")
label1.grid(row=3,column=0)

btn1=Button(tk,text="Check Output Voltatge",command=use_multimeter).grid(row=7,column=2)
btn2=Button(tk,text="Check Microcontroller",command=use_microcontroller).grid(row=7,column=3)
btn3=Button(tk,text="Reset all",command=reset).grid(row=8,column=0)

multimeter=Canvas(tk,height=200,width=300,bg="#4244A4")
multimeter.grid(row=3,column=2)

multimeter_text=multimeter.create_text(155,80,text="",fill="white",font=('Courier','12','bold'))

lcd=Canvas(tk,height=200,width=300,bg="#2EAD4B")
lcd.grid(row=3,column=3)

lcd_text=lcd.create_text(140,80,text="",fill="white",font=('Courier','12','bold'))

label2=Label(tk,text="Multimeter Screen").grid(row=4,column=2)
label3=Label(tk,text="Microcontroller Screen").grid(row=4,column=3)
label4=Label(tk,text="(Input Pin Voltage is set to 5V and Pin 3 is grounded)").grid(row=4,column=1)


options=["Temperature in Celsius","Temperature in Fahrenheit"]
clicked=StringVar()
clicked.set("Show temperature in Celsius")
drop=OptionMenu(tk,clicked,*options).grid(row=6,column=3)

tk.mainloop()