from ssl import OP_NO_TLSv1_2
from tkinter import *
import os.path
from tkinter import Canvas,Frame


tk=Tk()
tk.title("Gray Code to Binary Code")
tk.geometry("1080x600")
ckt_on=False

ckt=PhotoImage(file=os.path.join(os.getcwd(),"ic.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

Label(tk,image=ckt).grid(row=1,column=3,stick=NW)

op0=Label(tk,image=red)
op0.grid(row=1,column=4,stick=N,pady=30)

op1=Label(tk,image=red)
op1.grid(row=1,column=4,stick=N,pady=150)

op2=Label(tk,image=red)
op2.grid(row=1,column=4,stick=N,pady=245)

op3=Label(tk,image=red)
op3.grid(row=1,column=4,stick=N,pady=330)

input_options = ["0","1"]
G0=StringVar()
G0.set("0")

G1=StringVar()
G1.set("0")

G2=StringVar()
G2.set("0")

G3=StringVar()
G3.set("0")


def reset():
    global ckt_on
    ckt_on = False
    G0.set("0")
    G1.set("0")
    G2.set("0")
    G3.set("0")
    ckt_button.configure(image=off)
    op0.configure(image=red)
    op1.configure(image=red)
    op2.configure(image=red)
    op3.configure(image=red)

def switch():
    global ckt_on
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        op0.configure(image=red)
        op1.configure(image=red)
        op2.configure(image=red)
        op3.configure(image=red)


def simulate():
    def B0():
        if int(G0.get())^int(G1.get())^int(G2.get())^int(G3.get())==True:op0.configure(image=green)
        else:op0.configure(image=red)
    def B1():
        if int(G3.get())^int(G2.get())^int(G1.get())==True:op1.configure(image=green)
        else:op1.configure(image=red)
    def B2():
        if int(G3.get())^int(G2.get())==True:op2.configure(image=green)
        else:op2.configure(image=red)
    def B3():
        if int(G3.get())==True:op3.configure(image=green)
        else:op3.configure(image=red)

    if ckt_on==True:
        B0()
        B1()
        B2()
        B3()
    else:
        op0.configure(image=red)
        op1.configure(image=red)
        op2.configure(image=red)
        op3.configure(image=red)



drop0=OptionMenu(tk,G0,*input_options).grid(row=1,column=1,stick=N,pady=30)
drop1=OptionMenu(tk,G1,*input_options).grid(row=1,column=1,stick=N,pady=150)
drop2=OptionMenu(tk,G2,*input_options).grid(row=1,column=1,stick=N,pady=245)
drop3=OptionMenu(tk,G3,*input_options).grid(row=1,column=1,stick=N,pady=340)

Label(tk,text="Input G0 (LSB)").grid(row=1,column=0,stick=NE,pady=30)
Label(tk,text="Output B0 (LSB)").grid(row=1,column=5,stick=NW,pady=30)


Label(tk,text="Input G1").grid(row=1,column=0,stick=NE,pady=152)
Label(tk,text="Output B1").grid(row=1,column=5,stick=NW,pady=152)


Label(tk,text="Input G2").grid(row=1,column=0,stick=NE,pady=248)
Label(tk,text="Output B2").grid(row=1,column=5,stick=NW,pady=248)

Label(tk,text="Input G3 (MSB)").grid(row=1,column=0,stick=NE,pady=344)
Label(tk,text="Output B3 (MSB)").grid(row=1,column=5,stick=NW,pady=344)


Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)


ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)

Button(tk,text="Simulate",command=simulate,width=15).grid(row=1,column=4,pady=420,sticky=N) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=1,column=5,padx=20,pady=60) 

tk.mainloop()