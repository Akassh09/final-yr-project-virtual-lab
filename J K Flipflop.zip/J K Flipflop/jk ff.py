from tkinter import *
import os.path

tk=Tk()
tk.title("J K Flip FLop")
tk.geometry("1120x600")
ckt_on=False

input_options = ["0","1"]
j=IntVar()
j.set("0")

k=IntVar()
k.set("0")

prev=int(0)

ckt=PhotoImage(file=os.path.join(os.getcwd(),"jk ff.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

Label(tk,image=ckt).grid(row=1,column=3,stick=NW)

def switch():
    global ckt_on,prev
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        op1.configure(image=red)
        op2.configure(image=red)
        prev=0

def reset():
    global ckt_on,prev
    ckt_on = False
    ckt_button.configure(image=off)
    j.set("0")
    k.set("0")
    prev=0
    op1.configure(image=red)
    op2.configure(image=red)

def simulate():
    global j,k,prev
    J=int(j.get())
    K=int(k.get())

    global prev
    if ckt_on==True:

        if J==0 and K==0 and prev==0:
            op1.configure(image=red)
            op2.configure(image=green)
            prev=0

        elif J==0 and K==0 and prev==1:
            op1.configure(image=green)
            op2.configure(image=red)
            prev=1

        elif J==0 and K==1 and prev==0:
            op1.configure(image=red)
            op2.configure(image=green)
            prev=0
    
        elif J==0 and K==1 and prev==1:
            op1.configure(image=red)
            op2.configure(image=green)
            prev=0

        elif J==1 and K==0 and prev==0:
            op1.configure(image=green)
            op2.configure(image=red)
            prev=1
          
        elif J==1 and K==0 and prev==1:
            op1.configure(image=green)
            op2.configure(image=red)
            prev=1
         
        elif J==1 and K==1 and prev==0:
            op1.configure(image=green)
            op2.configure(image=red)
            prev=1

        elif J==1 and K==1 and prev==1:
            op1.configure(image=red)
            op2.configure(image=green)
            prev=0

    else:
            op1.configure(image=red)
            op2.configure(image=red)


drop1=OptionMenu(tk,j,*input_options).grid(row=1,column=1,stick=N,pady=70)
drop2=OptionMenu(tk,k,*input_options).grid(row=1,column=1,stick=N,pady=200)

Label(tk,text="Input J").grid(row=1,column=0,stick=NE,pady=75)
Label(tk,text="Input K").grid(row=1,column=0,stick=NE,pady=205)
Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)

ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)

Button(tk,text="Clock",command=simulate,width=15).grid(row=1,column=4,pady=320,sticky=N) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=1,column=5,padx=20,pady=100) 


op1=Label(tk,image=red)
op1.grid(row=1,column=4,stick=N,pady=45)
op2=Label(tk,image=red)
op2.grid(row=1,column=4,stick=N,pady=215)

Label(tk,text="Output Qn").grid(row=1,column=5,stick=NW,pady=45)
Label(tk,text="Output Qn'").grid(row=1,column=5,stick=NW,pady=215)

tk.mainloop()