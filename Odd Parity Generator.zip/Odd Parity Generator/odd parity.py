from tkinter import *
import os.path

tk=Tk()
tk.title("4-bit Odd Parity Generator")
tk.geometry("1120x500")

ckt_on=False

ckt=PhotoImage(file=os.path.join(os.getcwd(),"odd.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

Label(tk,image=ckt).grid(row=1,column=2,stick=NW)

input_options = ["0","1"]

A=IntVar()
A.set("0")

B=IntVar()
B.set("0")

C=IntVar()
C.set("0")

D=IntVar()
D.set("0")

def reset():
    global ckt_on
    ckt_on = False
    A.set("0")
    B.set("0")
    C.set("0")
    D.set("0")
    ckt_button.configure(image=off)
    op0.configure(image=red)

def switch():
    global ckt_on
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        op0.configure(image=red)

def o_parity():
    if   A.get()==0 and B.get()==0 and C.get()==0 and D.get()==0:
        op0.configure(image=green)
    elif A.get()==0 and B.get()==0 and C.get()==1 and D.get()==1:
        op0.configure(image=green)
    elif A.get()==0 and B.get()==1 and C.get()==0 and D.get()==1:
        op0.configure(image=green)
    elif A.get()==0 and B.get()==1 and C.get()==1 and D.get()==0:
        op0.configure(image=green)
    elif A.get()==1 and B.get()==0 and C.get()==0 and D.get()==1:
        op0.configure(image=green)
    elif A.get()==1 and B.get()==0 and C.get()==1 and D.get()==0:
        op0.configure(image=green)
    elif A.get()==1 and B.get()==1 and C.get()==0 and D.get()==0:
        op0.configure(image=green)
    elif A.get()==1 and B.get()==1 and C.get()==1 and D.get()==1:
        op0.configure(image=green)                
    else:
        op0.configure(image=red)
        


def simulate():    
    if ckt_on==True:
        o_parity()
    else:
        op0.configure(image=red)

drop0=OptionMenu(tk,A,*input_options).grid(row=1,column=1,stick=N,pady=20)
drop1=OptionMenu(tk,B,*input_options).grid(row=1,column=1,stick=N,pady=95)
drop2=OptionMenu(tk,C,*input_options).grid(row=1,column=1,stick=N,pady=175)
drop3=OptionMenu(tk,D,*input_options).grid(row=1,column=1,stick=N,pady=245)

op0=Label(tk,image=red)
op0.grid(row=1,column=3,sticky=N,pady=135,padx=20)
Label(tk,text="Odd Parity").grid(row=1,column=4,sticky=NW,pady=145,padx=20)


Label(tk,text="Input A").grid(row=1,column=0,stick=NE,pady=25)
Label(tk,text="Input B").grid(row=1,column=0,stick=NE,pady=100)
Label(tk,text="Input C").grid(row=1,column=0,stick=NE,pady=180)
Label(tk,text="Input D").grid(row=1,column=0,stick=NE,pady=250)

Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)

ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)


Button(tk,text="Simulate",command=simulate,width=15).grid(row=1,column=4,pady=330,sticky=NW) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=1,column=5,padx=20,pady=60) 

tk.mainloop()