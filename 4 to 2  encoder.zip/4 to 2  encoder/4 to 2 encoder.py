from tkinter import *
import os.path

tk=Tk()
tk.title("4 to 2 Encoder")
tk.geometry("1080x500")
ckt_on=False
k1=False
k2=False
k3=False
k4=False

ckt=PhotoImage(file=os.path.join(os.getcwd(),"encoder.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

Label(tk,image=ckt).grid(row=1,column=2,stick=NW)

def switch():
    global ckt_on
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        op1.configure(image=red)   
        op2.configure(image=red)
        

def key1():
    global k1,k2,k3,k4
    if k1==False :
        k1=True
        in1.configure(image=on)
        k2=False
        in2.configure(image=off)        
        k3=False
        in3.configure(image=off)     
        k4=False
        in4.configure(image=off)   

    else:
        k1= False
        in1.configure(image=off)    


def key2():
    global k2,k1,k3,k4
    if k2==False :
        k2=True
        in2.configure(image=on)
        k1=False
        in1.configure(image=off)      
        k3=False
        in3.configure(image=off)     
        k4=False
        in4.configure(image=off) 
    else:
        k2=False
        in2.configure(image=off)


def key3():
    global k3,k1,k2,k4
    if k3==False :
        k3=True
        in3.configure(image=on)
        k1=False
        in1.configure(image=off)
        k2=False
        in2.configure(image=off) 
        k4=False
        in4.configure(image=off) 

    else:
        k3=False
        in3.configure(image=off)


def key4():
    global k4,k1,k2,k3
    if k4==False :
        k4=True
        in4.configure(image=on)
        k1=False
        in1.configure(image=off)
        k2=False
        in2.configure(image=off)        
        k3=False
        in3.configure(image=off)     

    else:
        k4=False
        in4.configure(image=off)


def simulate():
    if ckt_on==True:
        if k1==True:
            op1.configure(image=green)   
            op2.configure(image=green)
        elif k2==True:
            op1.configure(image=green)   
            op2.configure(image=red)
        elif k3==True:
            op1.configure(image=red)   
            op2.configure(image=green)   
        elif k4==True:
            op1.configure(image=red)   
            op2.configure(image=red)   
        else:
            op1.configure(image=red)   
            op2.configure(image=red)

    else:
        op1.configure(image=red)   
        op2.configure(image=red)


def reset():
    global ckt_on,k1,k2,k3,k4
    ckt_on=False
    ckt_button.configure(image=off)
    k1=False
    in1.configure(image=off)
    k2=False
    in2.configure(image=off)        
    k3=False
    in3.configure(image=off)     
    k4=False
    in4.configure(image=off)
    op1.configure(image=red)   
    op2.configure(image=red)


Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)
ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)

in1= Button(tk,image = off,bd = 0,command =key1)
in1.grid(row=1,column=1,sticky=N,pady=10)
Label(tk,text="Input Y3").grid(row=1,column=0,sticky=NE,pady=10)

in2= Button(tk,image = off,bd = 0,command =key2)
in2.grid(row=1,column=1,sticky=N,pady=70)
Label(tk,text="Input Y2").grid(row=1,column=0,sticky=NE,pady=70)

in3= Button(tk,image = off,bd = 0,command =key3)
in3.grid(row=1,column=1,sticky=N,pady=175)
Label(tk,text="Input Y1").grid(row=1,column=0,sticky=NE,pady=175)

in4= Button(tk,image = off,bd = 0,command =key4)
in4.grid(row=1,column=1,sticky=N,pady=230)
Label(tk,text="Input Y0").grid(row=1,column=0,sticky=NE,pady=230)

op1=Label(tk,image=red)
op1.grid(row=1,column=3,sticky=N,pady=60,padx=20)
Label(tk,text="Output A0").grid(row=1,column=4,sticky=NW,pady=60,padx=20)
op2=Label(tk,image=red)
op2.grid(row=1,column=3,sticky=N,pady=160,padx=20)
Label(tk,text="Output A1").grid(row=1,column=4,sticky=NW,pady=160,padx=20)

Button(tk,text="Simulate",command=simulate,width=15).grid(row=1,column=4) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=1,column=5,padx=10)

tk.mainloop()