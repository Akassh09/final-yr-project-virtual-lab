from tkinter import *
import os.path

tk=Tk()
tk.title("2 bit Comparator Circuit")
tk.geometry("1000x720")
ckt_on=False

ckt=PhotoImage(file=os.path.join(os.getcwd(),"comparator.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

Label(tk,image=ckt).grid(row=1,column=3,stick=NW)

input_options = ["0","1"]
A0=IntVar()
A0.set("0")

A1=IntVar()
A1.set("0")

B0=IntVar()
B0.set("0")

B1=IntVar()
B1.set("0")

def switch():
    global ckt_on
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        op1.configure(image=red)
        op2.configure(image=red)
        op3.configure(image=red)

def reset():
    global ckt_on
    ckt_on = False
    ckt_button.configure(image=off)
    B1.set("0")
    B0.set("0")
    A1.set("0")
    A0.set("0")
    op1.configure(image=red)
    op2.configure(image=red)
    op3.configure(image=red)

def simulate():

    a0=bool(A0.get())
    a1=bool(A1.get())
    b0=bool(B0.get())
    b1=bool(B1.get())

    if ckt_on==True:
        if ((a1 and (not b1)) or (a0 and (not b1) and (not b0)) or (a1 and a0 and (not b0)))==True:
            op1.configure(image=green)
            op2.configure(image=red)
            op3.configure(image=red)
        elif (((a0 and b0) or ((not a0) and (not b0))) and ((a1 and b1) or ((not a1)and(not b1))))==True:
            op1.configure(image=red)
            op2.configure(image=green)
            op3.configure(image=red)
        elif ((b1 and(not a1)) or ((not a0) and b1 and b0) or ((not a1) and (not a0) and b0))==True:
            op1.configure(image=red)
            op2.configure(image=red)
            op3.configure(image=green)
        else:
            op1.configure(image=red)
            op2.configure(image=red)
            op3.configure(image=red)


    else:
        op1.configure(image=red)
        op2.configure(image=red)
        op3.configure(image=red)


drop0=OptionMenu(tk,A1,*input_options).grid(row=1,column=1,stick=N,pady=47)
drop1=OptionMenu(tk,A0,*input_options).grid(row=1,column=1,stick=N,pady=150)
drop2=OptionMenu(tk,B1,*input_options).grid(row=1,column=1,stick=N,pady=245)
drop3=OptionMenu(tk,B0,*input_options).grid(row=1,column=1,stick=N,pady=346)
Label(tk,text="Input A1 (MSB)").grid(row=1,column=0,stick=NE,pady=50)
Label(tk,text="Input A0 (LSB)").grid(row=1,column=0,stick=NE,pady=152)
Label(tk,text="Input B1 (MSB)").grid(row=1,column=0,stick=NE,pady=248)
Label(tk,text="Input B0 (LSB)").grid(row=1,column=0,stick=NE,pady=350)
Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)

ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)

Button(tk,text="Simulate",command=simulate,width=15).grid(row=1,column=4,pady=460,sticky=N) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=1,column=5,padx=20,pady=100) 

op1=Label(tk,image=red)
op1.grid(row=1,column=4,stick=N,pady=130)

op2=Label(tk,image=red)
op2.grid(row=1,column=4,stick=N,pady=235)

op3=Label(tk,image=red)
op3.grid(row=1,column=4,stick=N,pady=350)

Label(tk,text="Output X").grid(row=1,column=5,stick=NW,pady=130)
Label(tk,text="Output Y").grid(row=1,column=5,stick=NW,pady=235)
Label(tk,text="Output Z").grid(row=1,column=5,stick=NW,pady=350)

tk.mainloop()