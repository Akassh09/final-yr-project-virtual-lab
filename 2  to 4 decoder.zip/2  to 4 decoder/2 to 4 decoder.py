from tkinter import *
import os.path

tk=Tk()
tk.title("4 to 2 Decoder")
tk.geometry("1080x500")
ckt_on=False


ckt=PhotoImage(file=os.path.join(os.getcwd(),"decoder.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

Label(tk,image=ckt).grid(row=1,column=2,stick=NW)

input_options = ["0","1"]
A0=IntVar()
A0.set("0")

A1=IntVar()
A1.set("0")

def switch():
    global ckt_on
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        op1.configure(image=red)   
        op2.configure(image=red)
        op3.configure(image=red)   
        op4.configure(image=red)
 
def simulate():
    if ckt_on==True:
        if A0.get()==0 and A1.get()==0:
            op1.configure(image=green)   
            op2.configure(image=red)
            op3.configure(image=red)   
            op4.configure(image=red)
        elif A0.get()==0 and A1.get()==1:
            op1.configure(image=red)   
            op2.configure(image=green)
            op3.configure(image=red)   
            op4.configure(image=red)
        elif A0.get()==1 and A1.get()==0:
            op1.configure(image=red)   
            op2.configure(image=red)
            op3.configure(image=green)   
            op4.configure(image=red)
        elif A0.get()==1 and A1.get()==1:
            op1.configure(image=red)   
            op2.configure(image=red)
            op3.configure(image=red)   
            op4.configure(image=green)
        else:
            op1.configure(image=red)   
            op2.configure(image=red)
            op3.configure(image=red)   
            op4.configure(image=red)
            
    else:
        op1.configure(image=red)   
        op2.configure(image=red)
        op3.configure(image=red)   
        op4.configure(image=red)

def reset():
    global ckt_on
    ckt_on=False
    ckt_button.configure(image=off)
    A0.set("0")
    A1.set("0")
    op1.configure(image=red)   
    op2.configure(image=red)
    op3.configure(image=red)   
    op4.configure(image=red)
    


Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)
ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)

drop0=OptionMenu(tk,A0,*input_options).grid(row=1,column=1,stick=N,pady=110)
drop1=OptionMenu(tk,A1,*input_options).grid(row=1,column=1,stick=N,pady=180)

Label(tk,text="Input A0").grid(row=1,column=0,stick=NE,pady=115)
Label(tk,text="Input A1").grid(row=1,column=0,stick=NE,pady=185)

op1=Label(tk,image=red)
op1.grid(row=1,column=3,sticky=N,pady=45,padx=20)

op2=Label(tk,image=red)
op2.grid(row=1,column=3,sticky=N,pady=110,padx=20)

op3=Label(tk,image=red)
op3.grid(row=1,column=3,sticky=N,pady=180,padx=20)

op4=Label(tk,image=red)
op4.grid(row=1,column=3,sticky=N,pady=250,padx=20)


Button(tk,text="Simulate",command=simulate,width=15).grid(row=1,column=4,sticky=N,pady=310) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=1,column=5,sticky=N,pady=310,padx=10)

Label(tk,text="Output D0").grid(row=1,column=4,sticky=N,pady=45,padx=20)
Label(tk,text="Output D1").grid(row=1,column=4,sticky=N,pady=110,padx=20)
Label(tk,text="Output D2").grid(row=1,column=4,sticky=N,pady=180,padx=20)
Label(tk,text="Output D3").grid(row=1,column=4,sticky=N,pady=250,padx=20)

tk.mainloop()