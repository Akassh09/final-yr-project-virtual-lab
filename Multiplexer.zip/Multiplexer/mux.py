from tkinter import *
import os.path

tk=Tk()
tk.title("4:1 Multiplexer using logic gates")
tk.geometry("1080x700")
ckt_on=False


ckt=PhotoImage(file=os.path.join(os.getcwd(),"mux.png"))
red=PhotoImage(file=os.path.join(os.getcwd(),"red.png"))
green=PhotoImage(file=os.path.join(os.getcwd(),"green.png"))
on=PhotoImage(file=os.path.join(os.getcwd(),"on.png"))
off=PhotoImage(file=os.path.join(os.getcwd(),"off.png"))

Label(tk,image=ckt).grid(row=1,column=3,stick=NW)

input_options = ["0","1"]
S0=IntVar()
S0.set("0")

S1=IntVar()
S1.set("0")

D0=IntVar()
D0.set("0")

D1=IntVar()
D1.set("0")

D2=IntVar()
D2.set("0")

D3=IntVar()
D3.set("0")

def switch():
    global ckt_on
    if ckt_on==False : 
        ckt_on = True
        ckt_button.configure(image=on)
    else:
        ckt_on = False
        ckt_button.configure(image=off)
        op1.configure(image=red)

def reset():
    global ckt_on
    ckt_on = False
    ckt_button.configure(image=off)
    D0.set("0")
    D1.set("0")
    D2.set("0")
    D3.set("0")
    S0.set("0")
    S1.set("0")
    op1.configure(image=red)


def simulate():
    s0=bool(S0.get())
    s1=bool(S1.get())
    d0=bool(D0.get())
    d1=bool(D1.get())
    d2=bool(D2.get())
    d3=bool(D3.get())
    if ckt_on==True:
        if ((d0 and (not s1) and (not s0)) or (d1 and (not s1) and s0) or (d2 and s1 and (not s0)) or (d3 and s1 and s0))==True:
            op1.configure(image=green)
        else:op1.configure(image=red)
    else:op1.configure(image=red)

drop0=OptionMenu(tk,D0,*input_options).grid(row=1,column=1,stick=N,pady=20)
drop1=OptionMenu(tk,D1,*input_options).grid(row=1,column=1,stick=N,pady=80)
drop2=OptionMenu(tk,D2,*input_options).grid(row=1,column=1,stick=N,pady=140)
drop3=OptionMenu(tk,D3,*input_options).grid(row=1,column=1,stick=N,pady=200)
drop4=OptionMenu(tk,S0,*input_options).grid(row=1,column=1,stick=N,pady=300)
drop5=OptionMenu(tk,S1,*input_options).grid(row=1,column=1,stick=N,pady=360)

Label(tk,text="Data Input D0").grid(row=1,column=0,stick=NE,pady=20)
Label(tk,text="Data Input D1").grid(row=1,column=0,stick=NE,pady=80)
Label(tk,text="Data Input D2").grid(row=1,column=0,stick=NE,pady=140)
Label(tk,text="Data Input D3").grid(row=1,column=0,stick=NE,pady=200)
Label(tk,text="Selection Line S0").grid(row=1,column=0,stick=NE,pady=300)
Label(tk,text="Selection Line S1").grid(row=1,column=0,stick=NE,pady=360)


Label(tk,text="Circuit Switch",foreground="Blue",font=('Courier','12','bold')).grid(row=0,column=0,padx=20,stick=E)

ckt_button = Button(tk, image = off, bd = 0,command = switch)
ckt_button.grid(row=0,column=1,padx=20,pady=20)


Button(tk,text="Simulate",command=simulate,width=15).grid(row=1,column=4,pady=460,sticky=N) 
Button(tk,text="Reset All",command=reset,width=15).grid(row=1,column=5,padx=20,pady=100) 


op1=Label(tk,image=red)
op1.grid(row=1,column=4,stick=N,pady=230)
Label(tk,text="Output Y").grid(row=1,column=5,stick=NW,pady=240)

tk.mainloop()